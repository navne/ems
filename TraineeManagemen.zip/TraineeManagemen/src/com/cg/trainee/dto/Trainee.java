package com.cg.trainee.dto;

import java.io.Serializable;
import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "trainee1")
public class Trainee implements Serializable {
	
	@Id
	@Column(name = "trainee_id")
	@GeneratedValue(generator ="traineeId_generater" , strategy= GenerationType.SEQUENCE)
	@SequenceGenerator(name ="traineeId_generater" , sequenceName = "seq_trainee" , allocationSize =1 , initialValue = 100)
	private int traineeId ;
	
	@NotEmpty(message ="not null")
	@Column(name = "trainee_name")
	@Pattern(regexp="^[A-Z][a-z]+$",message="starting with capital")
	private String traineeName;
	
	@NotEmpty(message = "not null")
	@Column(name ="trainee_location")
	private String traineeLocation;
	
	@NotNull(message = "not null")
	@Column(name = "trainee_domain")
	private String traineeDomain;
	
	
	
	
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	

	public Trainee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Trainee(int traineeId, String traineeName, String traineeLocation,
			String traineeDomain) {
		super();
		this.traineeId = traineeId;
		this.traineeName = traineeName;
		this.traineeLocation = traineeLocation;
		this.traineeDomain = traineeDomain;

	}
	
	}
	
	
	
	


