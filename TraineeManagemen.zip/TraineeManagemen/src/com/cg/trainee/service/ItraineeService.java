package com.cg.trainee.service;

import com.cg.trainee.dto.Trainee;

public interface ItraineeService {
	
	
	public int insertTrainee(Trainee trainee) ;
	public void deleteTrainee(int id);
	public Trainee searchTrainee(int id) throws Exception;

}
