package com.cg.trainee.service;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.trainee.dao.ITraineeDao;
import com.cg.trainee.dto.Trainee;

@Service("service")
@Transactional
public class TraineeServiceImpl implements ItraineeService{
	
	@Autowired
	ITraineeDao traineedao;

	@Override
	public int insertTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return traineedao.insertTrainee(trainee);
	}

	@Override
	public void deleteTrainee(int id) {
		traineedao.deleteTrainee(id);
		
	}

	@Override
	public Trainee searchTrainee(int id) throws Exception {
		// TODO Auto-generated method stub
		return traineedao.searchTrainee(id);
	}

}
