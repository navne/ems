package com.cg.trainee.dao;


import java.sql.ResultSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.trainee.dto.Trainee;

@Repository("traineedao")
public class TraineeDaoImpl implements ITraineeDao {
	
	@PersistenceContext
	EntityManager EntityManager;

	@Override
	public int insertTrainee(Trainee trainee) {
		
		EntityManager.persist(trainee);
		EntityManager.flush();
		return trainee.getTraineeId();
			
	}

	@Override
	public void deleteTrainee(int id) {
		
		Query query = EntityManager.createQuery("Delete from Trainee where traineeId = :trainee_id");
		query.setParameter("trainee_id", id);
		query.executeUpdate();
		
	}

	@Override
	public Trainee searchTrainee(int id) throws Exception {
		
		Query query = EntityManager.createQuery(" from Trainee where traineeId = :trainee_id");
		query.setParameter("trainee_id", id);
		Trainee trainee = (Trainee) query.getSingleResult();
		
		
		
		
		
		return trainee;
	}
	
	
	
	
	

}
