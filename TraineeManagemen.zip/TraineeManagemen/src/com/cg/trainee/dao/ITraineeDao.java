package com.cg.trainee.dao;

import com.cg.trainee.dto.Trainee;

public interface ITraineeDao {
	
	
	public int insertTrainee(Trainee trainee);
	public void deleteTrainee(int id);
	public Trainee searchTrainee(int id) throws Exception;

}
