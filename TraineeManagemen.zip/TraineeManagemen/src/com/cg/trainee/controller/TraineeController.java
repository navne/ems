package com.cg.trainee.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.xml.ws.BindingType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.trainee.dto.Trainee;
import com.cg.trainee.service.ItraineeService;


@Controller
public class TraineeController {
	
	@Autowired
	private ItraineeService service;

	
	@RequestMapping(value="login" , method = RequestMethod.POST )
	public String login(@RequestParam("name") String user , @RequestParam("pass") String pass )
	{
		
		
		
		if(user.equals("admin") && pass.equals("admin"))
		{
			
			return "home";
		}
		else
		{
			return "index";
		}
		
	}
	
	@RequestMapping(value="add" , method = RequestMethod.GET )
	public String addTrainee( @ModelAttribute("my")Trainee trainee, Map<String, Object> model)
	{
		System.out.println("in controler");
		List<String> mlist = new ArrayList<String>();
		mlist.add("java");
		mlist.add("testing");
		mlist.add(".net");
		mlist.add("sap");
		model.put("mlist", mlist);
		
		return "traineeform";
		
	}
	
	
	
	@RequestMapping(value = "putdata" , method = RequestMethod.POST )
	public ModelAndView traineeSucess(@Valid@ModelAttribute("my")Trainee trainee , BindingResult error )
	{
		if(error.hasErrors())
		{
			return new ModelAndView("traineeform");
		}
		int id = service.insertTrainee(trainee);
		return new  ModelAndView("addsuccess" , "id" , id);
				
				
				
	}
	
	@RequestMapping(value ="delet" , method = RequestMethod.GET )
	public String deleteTraine()
	{
		return "entertrainee";
		
		
	}
	
	@RequestMapping(value ="delete" , method = RequestMethod.GET )
	public String deleteTrainee(@RequestParam("id") int id)
	{
		service.deleteTrainee(id);
		return "home";
		
		
	}
	
	
	@RequestMapping(value ="search" , method = RequestMethod.GET )
	public ModelAndView searchTrainee(@RequestParam("id") int id , @ModelAttribute("new")Trainee trainee)
	{
		 try {
			trainee = service.searchTrainee(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ModelAndView("deletform", "trainee" , trainee);
		
	}


		
	
	
	
	
	
}
