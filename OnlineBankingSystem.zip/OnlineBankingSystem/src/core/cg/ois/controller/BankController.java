package core.cg.ois.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.jboss.security.auth.spi.Users.User;

import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Customer;
import core.cg.ois.beans.ServiceTracker;
import core.cg.ois.beans.Transaction;
import core.cg.ois.beans.UserTable;
import core.cg.ois.exception.LoginException;
import core.cg.ois.service.IObsService;
import core.cg.ois.service.ObsServiceImpl;


@WebServlet("*.do")
public class BankController extends HttpServlet {
	UserTable user = null;
	IObsService service = null;

	@Override
	public void init() throws ServletException {
		user = new  UserTable();
		service = new ObsServiceImpl();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{

		String action = request.getServletPath();
		String actionPage = null;
		HttpSession session = null;
		int accountId = 0;

		switch (action) {
		case "/Home.do":
			int count = 0;
			session = request.getSession();
			if(session != null)
			{
			int userId = Integer.parseInt(request.getParameter("userId"));
			String pass = request.getParameter("pass");
			user.setUserId(userId);
			user.setPassword(pass);			
			try
			{
				accountId = service.loginProcess(user);
				System.out.println(accountId);
				AccountMaster master = service.getAccount(accountId);
				session.setAttribute("master", master);
				actionPage = "Home.jsp";
			} 
			catch (LoginException e) 
			{	
				System.out.println(e);
				actionPage = "ClientLogin.jsp";
			}
			}
			else
			{
				actionPage = "ClientLogin.jsp";
			}

			break;

		case "/mini.do":
			session = request.getSession(false);
			if(session != null)
			{
				AccountMaster master = (AccountMaster) session.getAttribute("master");
				int AccountId = master.getAccountId();
				try
				{
					List<Transaction> mList = service.getAllTransaction(AccountId);
					System.out.println(mList);
					session.setAttribute("mList", mList);
				}
				catch (LoginException e) {
					session.setAttribute("error", e);
					e.printStackTrace();
				}
				actionPage = "mini.jsp";
			}
			else
			{
				actionPage = "ClientLogin.jsp";
			}
			break;

		case "/ForgetPassword.do":
			actionPage = "securityQues.jsp";
			response.sendRedirect(actionPage);
			break;

		case "/forget.do":
			String ques = null;
			session = request.getSession(true);
			accountId = Integer.parseInt(request.getParameter("userId"));
			session.setAttribute("userId", accountId);
			try
			{
				ques = service.SecurityQues(accountId);
				System.out.println(ques);
				session.setAttribute("ques", ques);
				actionPage = "ans.jsp";
			}
			catch (LoginException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
				actionPage = "securityQues.jsp";
			}
			break;
		case "/recover.do":
			session = request.getSession(false);
			if(session != null)
			{
				String quess = (String) session.getAttribute("ques");
				System.out.println(quess);
				String transPass = request.getParameter("ans");

				try
				{
					int Id = service.confirmQues(quess, transPass);
					actionPage = "otp.jsp";
				} 
				catch (LoginException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else
			{
				actionPage ="index.jsp";
			}


			break;	

		case "/otp.do" :
			session = request.getSession(false);

			if(session != null)
			{
				Object accountId1 = session.getAttribute("userId");
				Integer Id = (Integer)accountId1;
				System.out.println(Id);
				String otp = request.getParameter("otp");
				if(otp.equals("sbq#p"))
				{
					actionPage = "changePass.jsp";
				}
			}
			else
			{
				actionPage = "otp.jsp";
			}

			break;
			
		case "/changePassword.do":
			session = request.getSession(false);
			int id = Integer.parseInt(request.getParameter("id"));
			session.setAttribute("userId", id);
			actionPage = "changePass.jsp";
			break;

		case "/changePass.do":
			session = request.getSession(false);
			if(session != null)
			{
				
				
				Object userId1 = session.getAttribute("userId");
				Integer Id = (Integer)userId1;

				System.out.println(Id);
				String pas = request.getParameter("pass");
				try {
					System.out.println(pas);
					service.passwordChange(Id, pas);
					actionPage = "ClientLogin.jsp";

				} catch (LoginException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else
			{
				actionPage = "index.jsp";
			}

			break;

		case "/updateAddress.do":
			session = request.getSession(false);
			if(session != null)
			{
				int accId =Integer.parseInt( request.getParameter("id"));
				System.out.println("in update" +accId);
				try
				{
					Customer cust = service.getPersonalDetails(accId);
					session.setAttribute("cust", cust);
					actionPage = "updateCustomer.jsp";

				}
				catch (LoginException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else
			{
				actionPage = "ClientLogin.jsp";
			}
			break;

		case "/Update.do" :
			session = request.getSession();
			String accId = request.getParameter("accId");
			 accountId = Integer.parseInt(accId);
			String cName = request.getParameter("cName");
			String cEmail = request.getParameter("cEmail");
			String cAddress = request.getParameter("cAddress");
			String cPanCard = request.getParameter("cPanCard");

			Customer cust = new Customer(accountId, cName, cEmail, cAddress, cPanCard);

			try
			{
				service.updateCustomer(cust);
				actionPage = "updateSucess.jsp";
				session.setAttribute("cust", cust);

			}
			catch (LoginException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}



			break;
			
		case "/ServiceRequest.do":
			session = request.getSession(false);
			if(session != null)
			{				
			 accId = request.getParameter("id");
			 accountId = Integer.parseInt(accId);
			 session.setAttribute("accId", accountId);
			
			actionPage = "servicerequest.jsp";
			}
			break;
			
			
			case "/requestCheckbook.do":
				session = request.getSession(false);
				 accountId = (Integer) session.getAttribute("accId");
				 String desc = request.getParameter("desc");
				 System.out.println(desc);
				if(session != null)
				{
					try 
					{
						int serviceId =service.requestCheckBook(accountId, desc);
						System.out.println(serviceId);
						session.setAttribute("serviceId", serviceId);
						request.setAttribute("id" , accountId);
						actionPage = "requestsuccess.jsp";
					}
					catch (LoginException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					
					System.out.println("in request" +accountId);
					
				}
			break;
			
			case "/trackServices.do" :
				session = request.getSession(false) ;
				 accountId = Integer.parseInt( request.getParameter("id"));
			try
			{
				List<ServiceTracker> mService =  new ArrayList<ServiceTracker>();
					mService =	service.trackRequest(accountId);
				session.setAttribute("mService", mService);
				actionPage = "trackService.jsp";
			} 
			catch (LoginException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
			
			case "/logout.do":
				session = request.getSession(false);
				session.invalidate();
				actionPage = "index.jsp";
				break;
				






		default:
			actionPage = "index.jsp";
			break;



		}
		RequestDispatcher rd = request.getRequestDispatcher(actionPage);
		rd.forward(request	, response);






	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
