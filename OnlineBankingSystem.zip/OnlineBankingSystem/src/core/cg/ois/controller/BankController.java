package core.cg.ois.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.jboss.security.auth.spi.Users.User;

import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Transaction;
import core.cg.ois.beans.UserTable;
import core.cg.ois.exception.LoginException;
import core.cg.ois.service.IObsService;
import core.cg.ois.service.ObsServiceImpl;


@WebServlet("*.do")
public class BankController extends HttpServlet {
	UserTable user = null;
	IObsService service = null;

	@Override
	public void init() throws ServletException {
		user = new  UserTable();
		service = new ObsServiceImpl();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{

		String action = request.getServletPath();
		String actionPage = null;
		HttpSession session = null;

		switch (action) {
		case "/Home.do":
			int count = 0;
			session = request.getSession();
			int userId = Integer.parseInt(request.getParameter("userId"));
			String pass = request.getParameter("pass");
			user.setUserId(userId);
			user.setPassword(pass);			
			try
			{
				int accountId = service.loginProcess(user);
				System.out.println(accountId);
				AccountMaster master = service.getAccount(accountId);
				session.setAttribute("master", master);
				actionPage = "Home.jsp";
			} 
			catch (LoginException e) 
			{	
				System.out.println(e);
				actionPage = "ClientLogin.jsp";
			}

			break;
			
		case "/mini.do":
			session = request.getSession(false);
			if(session != null)
			{
				AccountMaster master = (AccountMaster) session.getAttribute("master");
				int AccountId = master.getAccountId();
				try
				{
					List<Transaction> mList = service.getAllTransaction(AccountId);
					System.out.println(mList);
					session.setAttribute("mList", mList);
				}
				catch (LoginException e) {
					session.setAttribute("error", e);
					e.printStackTrace();
				}
				actionPage = "mini.jsp";
			}
			else
			{
				actionPage = "ClientLogin.jsp";
			}
			break;

		case "/ForgetPassword.do":
			actionPage = "securityQues.jsp";
			response.sendRedirect(actionPage);
			break;

		case "/forget.do":
			String ques = null;
			session = request.getSession(true);
			userId = Integer.parseInt(request.getParameter("userId"));
			session.setAttribute("userId", userId);
			try
			{
				ques = service.SecurityQues(userId);
				System.out.println(ques);
				session.setAttribute("ques", ques);
				actionPage = "ans.jsp";
			}
			catch (LoginException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
				actionPage = "securityQues.jsp";
			}
			break;
		case "/recover.do":
			session = request.getSession(false);
			if(session != null)
			{
			String quess = (String) session.getAttribute("ques");
			System.out.println(quess);
			String transPass = request.getParameter("ans");

			try
			{
				int Id = service.confirmQues(quess, transPass);
				actionPage = "otp.jsp";
			} 
			catch (LoginException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
			else
			{
				actionPage ="index.jsp";
			}
		
		
			break;	

		case "/otp.do" :
			session = request.getSession(false);
			
			if(session != null)
			{
			Object userId1 = session.getAttribute("userId");
			Integer Id = (Integer)userId1;
			System.out.println(Id);
			String otp = request.getParameter("otp");
			if(otp.equals("sbq#p"))
			{
				actionPage = "changePass.jsp";
			}
			}
			else
			{
				actionPage = "otp.jsp";
			}

			break;

		case "/changePass.do":
			session = request.getSession(false);
			if(session != null)
			{
				Object userId1 = session.getAttribute("userId");
				Integer Id = (Integer)userId1;
				String pas = request.getParameter("pass");
				try {
					service.passwordChange(Id, pas);
					actionPage = "ClientLogin.jsp";

				} catch (LoginException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else
			{
				actionPage = "index.jsp";
			}

			break;
			
		
			





		default:
			actionPage = "index.jsp";
			break;



		}
		RequestDispatcher rd = request.getRequestDispatcher(actionPage);
		rd.forward(request	, response);






	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
