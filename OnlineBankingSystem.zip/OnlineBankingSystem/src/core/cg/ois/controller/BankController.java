package core.cg.ois.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.jms.Session;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.jboss.security.auth.spi.Users.User;











import com.sun.javafx.tk.quantum.MasterTimer;

import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Customer;
import core.cg.ois.beans.PayeeTable;
import core.cg.ois.beans.ServiceTracker;
import core.cg.ois.beans.Transaction;
import core.cg.ois.beans.UserTable;
import core.cg.ois.exception.LoginException;
import core.cg.ois.service.IObsService;
import core.cg.ois.service.ObsServiceImpl;


@WebServlet("*.do")
public class BankController extends HttpServlet {
	UserTable user = null;
	IObsService service = null;
	AccountMaster master = null;

	@Override
	public void init() throws ServletException {
		user = new  UserTable();
		service = new ObsServiceImpl();
		master = new AccountMaster();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{

		String action = request.getServletPath();
		if(action==null) action="";
		System.out.println("URI: "+action);
		String actionPage = null;
		String accId = null;
		int accountId = 0;
		String id = null;
		int userId = 0;
		String ques = null;
		HttpSession session = request.getSession();


		switch (action) {
		case "/Home.do":
			id = request.getParameter("userId");
			String pass = request.getParameter("pass");
			if(id !=  null && pass != null)
			{
				userId = Integer.parseInt(id);

				user.setUserId(userId);
				user.setPassword(pass);	


				try
				{
					accountId = service.loginProcess(user);
					System.out.println(accountId);
					master = service.getAccount(accountId);
					session.setAttribute("master", master);
					session.setAttribute("userId", userId);
					actionPage = "Home.jsp";
				} 
				catch (LoginException e) 
				{	
					session.setAttribute("msg", e);
					actionPage = "ClientLogin.jsp";
				}


			}
			else
			{
				session.setAttribute("msg", "Please Login First");
				System.out.println("Please Login first");
			}


			break;

		case "/mini.do":
			System.out.println("mini");
			actionPage = process(session);

			break;

		case "/ForgetPassword.do":
			actionPage = "securityQues.jsp";
			response.sendRedirect(actionPage);
			break;

		case "/forget.do":
			id = request.getParameter("userId");
			userId = Integer.parseInt(id);
			session.setAttribute("userId", userId);
			try
			{
				ques = service.SecurityQues(userId);
				System.out.println(ques);
				session.setAttribute("ques", ques);
				actionPage = "ans.jsp";
			}
			catch (LoginException e) 
			{
				session.setAttribute("invalidId" , "userId Does Not exists" );
				e.printStackTrace();
				actionPage = "securityQues.jsp";
			}
			break;
		case "/recover.do":

			ques = (String) session.getAttribute("ques");
			System.out.println(ques);
			String transPass = request.getParameter("ans");

			try
			{
				int Id = service.confirmQues(ques, transPass);
				actionPage = "otp.jsp";
			} 
			catch (LoginException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}



			break;	

		case "/otp.do" :

			Object accId1 = session.getAttribute("userId");
			if(accId1 != null)
			{
				userId = Integer.parseInt((String) accId1);
				System.out.println(userId);
				String otp = request.getParameter("otp");
				if(otp.equals("sbq#p"))
				{
					actionPage = "changePass.jsp";
				}
			}
			else
			{
				actionPage = "securityQues.jsp";
			}


			break;

		case "/changePassword.do":
			id = request.getParameter("userId");
			if(id != null)
			{
				userId = Integer.parseInt(id);
				session.setAttribute("userId", userId);
				actionPage = "changePass.jsp";
			}
			else
			{
				actionPage = "securityQues.jsp";

			}
			break;

		case "/changePass.do":
			id = (String) session.getAttribute("userId");

			if(id != null )
			{
				userId = Integer.parseInt(id);

				System.out.println(userId);
				String pas = request.getParameter("pass");
				try 
				{
					System.out.println(pas);
					service.passwordChange(userId, pas);
					actionPage = "ClientLogin.jsp";

				} 
				catch (LoginException e)
				{
					session.setAttribute("error", "Unbale to ChangePassword");
					e.printStackTrace();
				}
			}
			else
			{
				actionPage = "index.jsp";
			}

			break;

		case "/updateAddress.do":
			id = (String) session.getAttribute("userId");
			if(id != null)
			{
				accId = request.getParameter("userId") ;

				accountId =Integer.parseInt(accId);
				System.out.println("in update" +accId);
				try
				{
					Customer cust = service.getPersonalDetails(accountId);
					session.setAttribute("cust", cust);
					actionPage = "updateCustomer.jsp";

				}
				catch (LoginException e) {
					session.setAttribute("error", "Unbale to retrieve Details");
					e.printStackTrace();
				}
			}

			else 
			{
				session.setAttribute("error", "Please Login First");
				actionPage = "ClientLogin.jsp";
			}


			break;

		case "/Update.do" :
			id = (String) session.getAttribute("userId");
			if(id != null)
			{
				accId = request.getParameter("accId");
				accountId = Integer.parseInt(accId);
				String cName = request.getParameter("cName");
				String cEmail = request.getParameter("cEmail");
				String cAddress = request.getParameter("cAddress");
				String cPanCard = request.getParameter("cPanCard");

				Customer cust = new Customer(accountId, cName, cEmail, cAddress, cPanCard);

				try
				{
					service.updateCustomer(cust);
					actionPage = "updateSucess.jsp";
					session.setAttribute("cust", cust);

				}
				catch (LoginException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			else 
			{
				session.setAttribute("error", "Please Login First");
				actionPage = "ClientLogin.jsp";
			}

			break;

		case "/ServiceRequest.do":
			id = (String) session.getAttribute("userId");
			if(id != null)
			{
				accId = request.getParameter("id");
				accountId = Integer.parseInt(accId);
				session.setAttribute("accId", accountId);

				actionPage = "servicerequest.jsp";
			}

			else 
			{
				session.setAttribute("error", "Please Login First");
				actionPage = "ClientLogin.jsp";
			}

			break;


		case "/requestCheckbook.do":
			id = (String) session.getAttribute("userId");
			if(id != null)
			{
				accountId = (Integer) session.getAttribute("accId");
				String desc = request.getParameter("desc");
				System.out.println(desc);

				try 
				{
					int serviceId =service.requestCheckBook(accountId, desc);
					System.out.println(serviceId);
					session.setAttribute("serviceId", serviceId);
					request.setAttribute("id" , accountId);
					actionPage = "requestsuccess.jsp";
				}
				catch (LoginException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			else 
			{
				session.setAttribute("error", "Please Login First");
				actionPage = "ClientLogin.jsp";
			}


			System.out.println("in request" +accountId);


			break;

		case "/trackServices.do" :
			id = (String) session.getAttribute("userId");
			if(id != null)
			{
				accountId = Integer.parseInt( request.getParameter("id"));
				try
				{
					List<ServiceTracker> mService =  new ArrayList<ServiceTracker>();
					mService =	service.trackRequest(accountId);
					session.setAttribute("mService", mService);
					actionPage = "trackService.jsp";
				} 
				catch (LoginException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			else 
			{
				session.setAttribute("error", "Please Login First");
				actionPage = "ClientLogin.jsp";
			}

			break;

		case "/logout.do":
			session = request.getSession(false);
			session.invalidate();
			response.sendRedirect("index.jsp");
			break;

			//		case "/fundTransfer.do":
			//			 accId = request.getParameter("id");
			//			 accountId = Integer.parseInt(accId);
			//			 System.out.println("in fund" +accId);
			//			 
			//			try
			//			{
			//				Customer customer  = service.getCustomerName(accountId);
			//				request.setAttribute("Customer", customer);
			//				actionPage = "FundsTransfer.jsp";
			//			}
			//			catch (LoginException e) {
			//				// TODO Auto-generated catch block
			//				e.printStackTrace();
			//				
			//			} 
			//			break;
			//			
			//			case "/ownAccountTransfer.do":
			//				 String customerName =  (String) request.getAttribute("cust");
			//				 System.out.println(customerName);
			//				 
			//			try
			//			{
			//				List<Integer> ownPayeeList = service.getownAccountList(customerName);
			//				System.out.println(ownPayeeList);
			//			}
			//			catch (LoginException e) {
			//				
			//				e.printStackTrace();
			//				System.out.println(e);
			//			}
			//			break;


		case"/fundTransfer.do":
			session = request.getSession(false);
			accId = request.getParameter("id");
			accountId = Integer.parseInt(accId);
			session.setAttribute("userId", accountId);
			actionPage ="mainFundTransfer.jsp";

			break;
		case"/ownTransfer.do":
			session = request.getSession(false);
			String id1 = request.getParameter("id");
			int userId3 = Integer.parseInt(id1);

			List<PayeeTable> list = new ArrayList<PayeeTable>();
			try
			{
				list = service.getPayeeList(userId3);
				System.out.println(list);
				session.setAttribute("userId", userId3);
				session.setAttribute("payeeList", list);

				actionPage = "ownTransfer.jsp";
			} 
			catch (LoginException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


			break;
			//				
		case "/fundownTransfer.do":
			session = request.getSession(false);

			int accountPayer=Integer.parseInt(request.getParameter("payer"));
			int accountPayee=Integer.parseInt(request.getParameter("payee"));
			double amount=Double.parseDouble(request.getParameter("amount"));


			try {
				int transId =service.ownFundTransfer(accountPayer, accountPayee, amount);
				session.setAttribute("transId", transId);
				actionPage = "success.jsp";

			} catch (LoginException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}



			break;
			//			case"/otherTransfer.do":
			//				int userId4=(int) session.getAttribute("userId");
			//				List<UserTable> list1=dao.getAccountId(userId4);
			//				request.setAttribute("accountIds", list1);
			//				RequestDispatcher ds1=request.getRequestDispatcher("/view/otherTransfer.jsp");
			//				ds1.forward(request, response);
			//				break;
			//				
			//			case"/genpayee.do":
			//				int accId=Integer.parseInt(request.getParameter("payer"));
			//				List <PayeeTable> payeeList=dao.getPayee(accId);
			//				request.setAttribute("payeeList",payeeList );
			//				RequestDispatcher ds2=request.getRequestDispatcher("/view/otherTransfer.jsp");
			//				ds2.forward(request, response);
			//				break;
			//				
		case"/addPayee.do":
			accountId=Integer.parseInt(request.getParameter("payer"));
			request.setAttribute("payer", accountId );
			actionPage ="enterPayeeDetails.jsp";
			break;
			//				
		case"/addPayeeTable.do":
			session = request.getSession(false);
			int accId2=Integer.parseInt(request.getParameter("accountId"));
			int payeeaccId=Integer.parseInt(request.getParameter("payeeAccountId"));
			String nickname=request.getParameter("nickname");

			PayeeTable payee=new PayeeTable(accId2,payeeaccId,nickname);

			session.setAttribute("Payee",payee);
			try 
			{
				service.checkPayeeId(payeeaccId);
				actionPage = "Urn.jsp";
			}
			catch (LoginException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;


		case"/addPayeeConfirm.do":
			session = request.getSession(false);
			PayeeTable payee1 = (PayeeTable) session.getAttribute("Payee");
			System.out.println(payee1);
			String urn = request.getParameter("urn");
			if(urn.equals("abc"))
			{
				try 
				{
					service.addPayee(payee1);
					actionPage = "payeeSuccess.jsp";
				}
				catch (LoginException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}


			break;

			//			case "/firstpage.do":
			//			{
			//				response.sendRedirect("/New/view/home.jsp");
			//				break;
			//			}











		default:
			actionPage = "index.jsp";
			break;



		}
		RequestDispatcher rd = request.getRequestDispatcher("secured/"+actionPage);
		rd.forward(request	, response);






	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	private String process(HttpSession session)
	{
	    Object id = session.getAttribute("userId");
		if(id != null)
		{
		master = (AccountMaster) session.getAttribute("master");
		int AccountId = master.getAccountId();
		try
		{
			List<Transaction> mList = service.getAllTransaction(AccountId);
			System.out.println(mList);
			session.setAttribute("mList", mList);
		}
		catch (LoginException e) {
			session.setAttribute("error", e);
			e.printStackTrace();
		}
		return "mini.jsp";
		}

		else 
		{
			session.setAttribute("error", "Please Login First");
			return "ClientLogin.jsp";
		}

		
	}
}
