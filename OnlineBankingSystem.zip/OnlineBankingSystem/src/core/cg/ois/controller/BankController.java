package core.cg.ois.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.jms.Session;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.jboss.security.auth.spi.Users.User;












import com.sun.javafx.tk.quantum.MasterTimer;
import com.sun.org.apache.regexp.internal.recompile;

import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Customer;
import core.cg.ois.beans.PayeeTable;
import core.cg.ois.beans.ServiceTracker;
import core.cg.ois.beans.Transaction;
import core.cg.ois.beans.UserTable;
import core.cg.ois.exception.LoginException;
import core.cg.ois.service.IObsService;
import core.cg.ois.service.ObsServiceImpl;


@WebServlet("*.do")
public class BankController extends HttpServlet {
	UserTable user = null;
	IObsService service = null;
	AccountMaster master = null;

	@Override
	public void init() throws ServletException {
		user = new  UserTable();
		service = new ObsServiceImpl();
		master = new AccountMaster();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{

		String action = request.getServletPath();
		if(action==null) action="";
		System.out.println("URI: "+action);
		String actionPage = null;
		String accId = null;
		int accountId = 0;
		String id = null;
		int userId = 0;
		String ques = null;	
		Object obj = null;

		switch (action) {

		case "/login.do":
			HttpSession session = request.getSession(true);
		


			id = request.getParameter("userId");
			String pass = request.getParameter("pass");
			if(id != null && pass != null)
			{

				userId = Integer.parseInt(id);
				System.out.println(userId);

				user.setUserId(userId);
				user.setPassword(pass);	


				try
				{
					accountId = service.loginProcess(user);
					session.setAttribute("accountId", accountId);
					session.setAttribute("userId", userId);
					session.setAttribute("pass", pass);
					actionPage = "Home.do";
				} 
				catch (LoginException e) 
				{	
					
					e.printStackTrace();
					session.setAttribute("msg", e);
					actionPage = "clientlogin.jsp";
				}
			}
			else
			{
				actionPage = "clientlogin.jsp";
			}


			break;

		case "/Home.do":
			System.out.println("inhome");

			session = request.getSession(false);

			obj = session.getAttribute("accountId");
			if(obj != null)
			{
				accountId = (int)obj;


				try
				{

					master = service.getAccount(accountId);
					Customer cust = service.getCustomerName(accountId);
					session.setAttribute("cust", cust);
					session.setAttribute("master", master);
					actionPage = "Home.jsp";
				} 
				catch (LoginException e) 
				{	
					e.printStackTrace();
					session.setAttribute("msg", e);
					actionPage = "clientlogin.jsp";
				}
			}
			else
			{
				actionPage = "clientlogin.jsp";
			}





			break;

		case "/mini.do":

			session = request.getSession(false);
			System.out.println("mini");
			actionPage = process(session);

			break;

		case "/ForgetPassword.do":
			actionPage = "securityQues.jsp";
			response.sendRedirect(actionPage);
			break;

		case "/forget.do":
			session = request.getSession(false);

			if(session != null)
			{
				id = request.getParameter("userId");
				userId = Integer.parseInt(id);
				session.setAttribute("userId", userId);
				try
				{
					ques = service.securityQues(userId);
					System.out.println(ques);
					session.setAttribute("ques", ques);
					actionPage = "ans.jsp";
				}
				catch (LoginException e) 
				{
					session.setAttribute("invalidId" , "userId Does Not exists" );
					e.printStackTrace();
					actionPage = "securityQues.jsp";
				}
			}
			else
			{
				actionPage = "clientlogin.jsp";
			}
			break;
		case "/recover.do":
			session = request.getSession(false);
			ques = (String) session.getAttribute("ques");
			if( ques != null)
			{
				System.out.println(ques);
				String transPass = request.getParameter("ans");

				try
				{
					int Id = service.confirmQues(ques, transPass);
					System.out.println("eea"+Id);
					actionPage = "otp.jsp";
				} 
				catch (LoginException e) {
					actionPage = "ans.jsp";
					session.setAttribute("error", "Inavlid Answer");
					e.printStackTrace();
				}
			}
			else
			{
				actionPage = "clientogin.jsp";
			}



			break;	

		case "/otp.do" :
			session = request.getSession(false);


			String otp = request.getParameter("otp");
			if(otp.equals("abc"))
			{
				actionPage = "changePass.jsp";
			}
			else
			{
				actionPage = "otp.jsp";
				session.setAttribute("errorotp", "Wrong Otp");	

			}


			break;

		case "/changePassword.do":
			session = request.getSession(false);

			obj = session.getAttribute("userId");
			if(obj != null)
			{

				userId = (int)obj;
				session.setAttribute("userId", userId);
				actionPage = "changePass.jsp";
			}
			else
			{
				actionPage = "clientlogin.jsp";
			}


			break;

		case "/changePass.do":
			session = request.getSession(false);

			obj =  session.getAttribute("userId");
			String pas = request.getParameter("pass");
			System.out.println("int"+ obj);
			if(obj != null && pas != null)
			{


				userId = (int)obj;

				System.out.println(userId);

				try 
				{
					System.out.println(pas);
					service.passwordChange(userId, pas);
					actionPage = "clientlogin.jsp";

				} 
				catch (LoginException e)
				{

					session.setAttribute("msg", "Unbale to ChangePassword");
					e.printStackTrace();
					actionPage = "cientlogin.jsp";
				}
			}
			else
			{
				actionPage = "clientlogin.jsp";
			}


			break;

		case "/updateAddress.do":
			session = request.getSession(false);

			//			    userId = (int) session.getAttribute("userId");

			accId = request.getParameter("id") ;
			if(accId != null)
			{

				accountId =Integer.parseInt(accId);
				System.out.println("in update" +accId);
				try
				{
					Customer cust = service.getPersonalDetails(accountId);
					session.setAttribute("cust", cust);
					actionPage = "updateCustomer.jsp";

				}
				catch (LoginException e) {
					session.setAttribute("errorupdate", "Unbale to retrieve Details");
					e.printStackTrace();
				}
			}
			else
			{
				actionPage ="clientlogin.jsp";
			}




			break;

		case "/Update.do" :
			session = request.getSession(false);

			obj = session.getAttribute("userId");
			if(obj != null)
			{

				userId =   (int) obj;

				accId = request.getParameter("accId");
				accountId = Integer.parseInt(accId);
				String cName = request.getParameter("cName");
				String cEmail = request.getParameter("cEmail");
				String cAddress = request.getParameter("cAddress");
				String cPanCard = request.getParameter("cPanCard");

				Customer cust = new Customer(accountId, cName, cEmail, cAddress, cPanCard);

				try
				{
					service.updateCustomer(cust);
					actionPage = "updateSucess.jsp";
					session.setAttribute("cust", cust);

				}
				catch (LoginException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else
			{
				actionPage = "clientlogin.jsp";
			}




			break;

		case "/ServiceRequest.do":
			session = request.getSession(false);

			//			userId = (int) session.getAttribute("userId");

			accId = request.getParameter("id");
			if(accId != null)
			{
				accountId = Integer.parseInt(accId);
				session.setAttribute("accId", accountId);

				actionPage = "servicerequest.jsp";
			}
			else 
			{
				actionPage ="clientlogin.jsp";
			}


			break;


		case "/requestCheckbook.do":
			session = request.getSession(false);

			//			int = (String) session.getAttribute("userId");

			obj =  session.getAttribute("accId");
			if(obj != null)
			{
				accountId = (int)obj;
				String desc = request.getParameter("desc");
				System.out.println(desc);

				try 
				{
					int serviceId =service.requestCheckBook(accountId, desc);
					System.out.println(serviceId);
					session.setAttribute("serviceId", serviceId);
					request.setAttribute("id" , accountId);
					actionPage = "requestsuccess.jsp";
				}
				catch (LoginException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else
			{
				actionPage = "clientlogin.jsp";
			}



			System.out.println("in request" +accountId);


			break;

		case "/trackServices.do" :
			session = request.getSession(false);

			//			id = (String) session.getAttribute("userId");
			accId = request.getParameter("id");
			if(accId != null)
			{

				accountId = Integer.parseInt(accId);
				try
				{
					List<ServiceTracker> mService =  new ArrayList<ServiceTracker>();
					mService =	service.trackRequest(accountId);
					session.setAttribute("mService", mService);
					actionPage = "trackService.jsp";
				} 
				catch (LoginException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else
			{
				actionPage = "clientlogin.jsp";
			}


			break;

		case "/logout.do":
			session = request.getSession(false);
			if(session != null)
			{


				session.invalidate();
				actionPage = "clientlogin.jsp";
			}
			else
			{
				actionPage = "clientlogin.jsp";
			}
			break;

			//		case "/fundTransfer.do":
			//			 accId = request.getParameter("id");
			//			 accountId = Integer.parseInt(accId);
			//			 System.out.println("in fund" +accId);
			//			 
			//			try
			//			{
			//				Customer customer  = service.getCustomerName(accountId);
			//				request.setAttribute("Customer", customer);
			//				actionPage = "FundsTransfer.jsp";
			//			}
			//			catch (LoginException e) {
			//				// TODO Auto-generated catch block
			//				e.printStackTrace();
			//				
			//			} 
			//			break;
			//			
			//			case "/ownAccountTransfer.do":
			//				 String customerName =  (String) request.getAttribute("cust");
			//				 System.out.println(customerName);
			//				 
			//			try
			//			{
			//				List<Integer> ownPayeeList = service.getownAccountList(customerName);
			//				System.out.println(ownPayeeList);
			//			}
			//			catch (LoginException e) {
			//				
			//				e.printStackTrace();
			//				System.out.println(e);
			//			}
			//			break;


		case"/fundTransfer.do":
			session = request.getSession(false);


			accId = request.getParameter("id");
			if(accId != null)
			{
				accountId = Integer.parseInt(accId);
				session.setAttribute("accountId", accountId);
				actionPage ="mainFundTransfer.jsp";
			}
			else
			{
				actionPage ="clientlogin.jsp";
			}

			break;
		case"/ownTransfer.do":
			session = request.getSession(false);


			String id1 = request.getParameter("id");
			if(id1 != null)
			{
				accountId = Integer.parseInt(id1);

				List<PayeeTable> list = new ArrayList<PayeeTable>();
				try
				{
					list = service.getPayeeList(accountId);
					System.out.println(list);
					session.setAttribute("accountId", accountId);
					session.setAttribute("payeeList", list);

					actionPage = "ownTransfer.jsp";
				} 
				catch (LoginException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else
			{
				actionPage ="clientlogin.jsp";
			}


			break;



		case "/fundownTransfer.do":
			session = request.getSession(false);
			String payer =request.getParameter("payer");
			String payee =request.getParameter("payee")	;
			String amt = request.getParameter("amount");

			if(payer != null && payee != null & amt != null)
			{


				int accountPayer=Integer.parseInt(payer);
				int accountPayee=Integer.parseInt(payee);
				double amount = Double.parseDouble(amt);


				try {
					int transId =service.ownFundTransfer(accountPayer, accountPayee, amount);
					session.setAttribute("transId", transId);
					actionPage = "success.jsp";

				} catch (LoginException e1) {

					e1.printStackTrace();
				}
			}
			else
			{
				actionPage = "clientlogin.jsp";
			}



			break;
			//			case"/otherTransfer.do":
			//				int userId4=(int) session.getAttribute("userId");
			//				List<UserTable> list1=dao.getAccountId(userId4);
			//				request.setAttribute("accountIds", list1);
			//				RequestDispatcher ds1=request.getRequestDispatcher("/view/otherTransfer.jsp");
			//				ds1.forward(request, response);
			//				break;
			//				
			//			case"/genpayee.do":
			//				int accId=Integer.parseInt(request.getParameter("payer"));
			//				List <PayeeTable> payeeList=dao.getPayee(accId);
			//				request.setAttribute("payeeList",payeeList );
			//				RequestDispatcher ds2=request.getRequestDispatcher("/view/otherTransfer.jsp");
			//				ds2.forward(request, response);
			//				break;
			//				
		case"/addPayee.do":
			session   = request.getSession(false);
			accountId = Integer.parseInt(request.getParameter("payer"));
			System.out.println(accountId);
			request.setAttribute("payer", accountId );
			actionPage ="enterPayeeDetails.jsp";
			break;
			//				
		case"/addPayeeTable.do":
			session = request.getSession(false);
			if(session !=  null)
			{


				int accId2=Integer.parseInt(request.getParameter("accountId"));
				int payeeaccId=Integer.parseInt(request.getParameter("payeeAccountId"));
				String nickname=request.getParameter("nickname");

				PayeeTable payee1=new PayeeTable(accId2,payeeaccId,nickname);

				session.setAttribute("Payee",payee1);
				try 
				{
					service.checkPayeeId(payeeaccId);
					actionPage = "Urn.jsp";
				}
				catch (LoginException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else
			{
				actionPage ="clientlogin.jsp";
			}
			break;


		case"/addPayeeConfirm.do":
			session = request.getSession(false);

			obj = session.getAttribute("Payee");
			if(obj != null)
			{
				PayeeTable payee1 = (PayeeTable) obj;


				System.out.println(payee1);
				String urn = request.getParameter("urn");
				if(urn.equals("abc"))
				{
					try 
					{
						service.addPayee(payee1);
						actionPage = "payeeSuccess.jsp";
					}
					catch (LoginException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			else
			{
				actionPage ="clientlogin.jsp";
			}


			break;
		case "/register.do":
			action = "register.jsp";

			//			case "/firstpage.do":
			//			{
			//				response.sendRedirect("/New/view/home.jsp");
			//				break;
			//			}

		case "/registerDetails.do":
			session = request.getSession();

			int accountId1 = Integer.parseInt(request.getParameter("accountId"));
			int userId1=Integer.parseInt(request.getParameter("userId"));
			String password1=request.getParameter("password");
			String secretQuestion=request.getParameter("secretQuestion");
			String transactionPassword=request.getParameter("transactionPassword");
			UserTable user=new UserTable(accountId1, userId1, password1, secretQuestion, transactionPassword, "0");
			boolean flag=false;
			try {
				flag = service.register(user);
			} catch (LoginException e1) {
				
				session.setAttribute("mesg", "Please Contact Bank");
				actionPage = "register.jsp";

			}
			if(flag==true)
			{
				session.setAttribute("user", user);
				actionPage = "successregister.jsp";
			}
			else
			{
				PrintWriter out = response.getWriter();
				out.println("invalid useriDd");
			}


			break;







		default:
			actionPage = "index.jsp";
			break;



		}
		RequestDispatcher rd = request.getRequestDispatcher(actionPage);
		rd.forward(request	, response);






	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	private String process(HttpSession session)
	{

		if(session != null)
		{

			Object obj = session.getAttribute("master");
			if(obj != null)
			{
				master = (AccountMaster) session.getAttribute("master");
				int AccountId = master.getAccountId();
				try
				{
					List<Transaction> mList = service.getAllTransaction(AccountId);
					System.out.println(mList);
					session.setAttribute("mList", mList);
				}
				catch (LoginException e) {
					session.setAttribute("errormini", "No tansactions");
					e.printStackTrace();
				}
				return "mini.jsp";
			}

			else
			{
				return "clientlogin.jsp";
			}
		}
		else
		{
			return "clientlogin.jsp";
		}



	}
}
