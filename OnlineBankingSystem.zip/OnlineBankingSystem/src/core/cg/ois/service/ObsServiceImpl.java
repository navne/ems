package core.cg.ois.service;

import java.util.List;

import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Transaction;
import core.cg.ois.beans.UserTable;
import core.cg.ois.dao.IObsDao;
import core.cg.ois.dao.ObsDaoImpl;
import core.cg.ois.exception.LoginException;

public class ObsServiceImpl implements IObsService {
	private IObsDao dao = null;




	public ObsServiceImpl() {
		dao = new ObsDaoImpl();
		// TODO Auto-generated constructor stub
	}




	@Override
	public int loginProcess(UserTable user) throws LoginException {
		return dao.loginProcess(user);
		// TODO Auto-generated method stub

	}




	@Override
	public void update(int lock) {
		dao.update(lock);
		
	}




	@Override
	public AccountMaster getAccount(int accountId) throws LoginException {
		// TODO Auto-generated method stub
		return dao.getAccount(accountId);
	}




	@Override
	public String SecurityQues(int userId) throws LoginException {
		// TODO Auto-generated method stub
		return dao.SecurityQues(userId);
	}




	@Override
	public int confirmQues(String ques, String transPass) throws LoginException {
		// TODO Auto-generated method stub
		return dao.confirmQues(ques, transPass);
	}




	@Override
	public void passwordChange(int userId, String pas) throws LoginException {
		dao.passwordChange(userId, pas);
		
	}




	@Override
	public List<Transaction> getAllTransaction(int accId) throws LoginException {
		// TODO Auto-generated method stub
		return dao.getAllTransaction(accId);
	}

}
