package core.cg.ois.beans;

public class PayeeTable 
{
	private int accountId;
	private int payeeAccountId;
	private String nickname;
	public PayeeTable() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PayeeTable(int accountId, int payeeAccountId, String nickname) {
		super();
		this.accountId = accountId;
		this.payeeAccountId = payeeAccountId;
		this.nickname = nickname;
	}
	@Override
	public String toString() {
		return "PayeeTable [accountId=" + accountId + ", payeeAccountId="
				+ payeeAccountId + ", nickname=" + nickname + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountId;
		result = prime * result
				+ ((nickname == null) ? 0 : nickname.hashCode());
		result = prime * result + payeeAccountId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PayeeTable other = (PayeeTable) obj;
		if (accountId != other.accountId)
			return false;
		if (nickname == null) {
			if (other.nickname != null)
				return false;
		} else if (!nickname.equals(other.nickname))
			return false;
		if (payeeAccountId != other.payeeAccountId)
			return false;
		return true;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public int getPayeeAccountId() {
		return payeeAccountId;
	}
	public void setPayeeAccountId(int payeeAccountId) {
		this.payeeAccountId = payeeAccountId;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	
	
}
