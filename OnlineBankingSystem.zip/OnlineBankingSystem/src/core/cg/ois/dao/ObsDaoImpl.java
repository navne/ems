package core.cg.ois.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Transaction;
import core.cg.ois.beans.UserTable;
import core.cg.ois.exception.LoginException;
import core.cg.ois.util.dbUtil;

public class ObsDaoImpl implements IObsDao {


	public int loginProcess(UserTable user) throws LoginException {
		String status= null;
		int accountId = 0;


		Connection con         = dbUtil.getConnection();
		PreparedStatement pstm = null;

		List<UserTable> login =new ArrayList<UserTable>();



		String Query = "SELECT LOCK_STATUS , Account_Id  FROM USER_TABLE where USER_ID = ? AND login_PASSWORD = ? ";
		ResultSet res = null;
		try
		{
			pstm = con.prepareStatement(Query);
			pstm.setInt(1, user.getUserId());
			pstm.setString(2, user.getPassword());

			res = pstm.executeQuery();

			while(res.next())
			{
				status = res.getString("Lock_status");
				accountId = res.getInt("Account_id");


			}
			if(accountId == 0)
			{
				throw new LoginException("Invalid UserIdPassWord");	

			}

			if(status.equals("1"))
			{
				throw new LoginException("Account is locked Please contact Admin");
			}



		} 
		catch (SQLException e)
		{
			throw new LoginException("Please contact bank admin "  +e);
		}
		finally
		{
			if(con != null && pstm != null && res != null)
			{
				try
				{
					con.close();
					pstm.close();
					res.close();
				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		return accountId;

	}

	@Override
	public void update(int lock) {

		Connection con = dbUtil.getConnection();
		PreparedStatement pstm = null;
		String queryTwo = "update lockstatus = 1 where userId = ?";
		try 
		{
			pstm = con.prepareStatement(queryTwo);
			pstm.setInt(1, lock);
			pstm.executeUpdate();
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("unable to update lock status " +e);
		}


	}

	@Override
	public AccountMaster getAccount(int accountId) throws LoginException {
		Connection con = dbUtil.getConnection();
		PreparedStatement pstm = null;
		AccountMaster master= new AccountMaster();
		String QueryThree = "Select * from Accountmaster where account_id=?";
		try 
		{
			pstm = con.prepareStatement(QueryThree);
			System.out.println(accountId);
			pstm.setInt(1, accountId);
			ResultSet resOne = pstm.executeQuery();

			while (resOne.next()) 
			{
				master.setAccountId(resOne.getInt(1));
				master.setAccountBalance(resOne.getDouble(3));
				master.setAccountType(resOne.getString(2));
				master.setOpenDate(resOne.getDate(4));


			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new LoginException("Something went Wrong" +e);

		}
		finally
		{
			if(con != null && pstm != null )
			{
				try
				{
					con.close();
					pstm.close();

				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
			}	


		}
		return master;
	}

	@Override
	public String SecurityQues(int userId) throws LoginException {
		Connection con         = dbUtil.getConnection();
		PreparedStatement pstm = null;
		String ques = null;


		String Query = "SELECT secret_question FROM USER_TABLE where USER_ID=?";
		ResultSet res = null;
		try
		{
			pstm = con.prepareStatement(Query);
			pstm.setInt(1,userId);


			res = pstm.executeQuery();

			while(res.next())
			{
				ques = res.getString("secret_question");


			}
			if(ques.isEmpty())
			{
				throw new LoginException("Invalid UserId");	

			}


		} 
		catch (SQLException e)
		{
			throw new LoginException("Please contact bank admin "  +e);
		}
		finally
		{
			if(con != null && pstm != null && res != null)
			{
				try
				{
					con.close();
					pstm.close();
					res.close();
				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		return ques;

	}

	@Override
	public int confirmQues(String ques, String transPass) throws LoginException {
		int accountId = 0;
		Connection con         = dbUtil.getConnection();
		PreparedStatement pstm = null;




		String Query = "SELECT  Account_Id  FROM USER_TABLE where transaction_password = ? ";
		ResultSet res = null;
		try
		{
			pstm = con.prepareStatement(Query);
			
			pstm.setString(1, transPass);

			res = pstm.executeQuery();

			while(res.next())
			{

				accountId = res.getInt("Account_id");


			}
			if(accountId == 0)
			{
				throw new LoginException("Invalid Security Ques");	

			}




		} 
		catch (SQLException e)
		{
			throw new LoginException("Please contact bank admin "  +e);
		}
		finally
		{
			if(con != null && pstm != null && res != null)
			{
				try
				{
					con.close();
					pstm.close();
					res.close();
				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		return accountId;

	}

	@Override
	public void passwordChange(int userId, String pas) throws LoginException {
		Connection con = dbUtil.getConnection();
		PreparedStatement pstm = null;
		
		String queryFour = "update user_table set login_password=? where user_id = ?";
		try 
		{
			pstm = con.prepareStatement(queryFour);
			pstm.setString(1, pas);
			pstm.setInt(2, userId);
			
			pstm.executeUpdate();
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
		   e.printStackTrace();
		   throw new LoginException("unable to change password" +e);
		}
		finally
		{
			if(con != null && pstm != null )
			{
				try
				{
					con.close();
					pstm.close();
					
				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		
	}

	@Override
	public List<Transaction> getAllTransaction(int accId) throws LoginException {
		List<Transaction> mTransactions = new ArrayList<Transaction>();
		Connection con = dbUtil.getConnection();
		Transaction trans = null;
		
		
		PreparedStatement pstm = null;
		try 
		{
			String queryFive =  "select * from transaction where account_no = ?";
			pstm = con.prepareStatement(queryFive);
			pstm.setInt(1, accId);
			ResultSet res = pstm.executeQuery();
			while(res.next())
			{
				trans = new Transaction();
				trans.setTransactionId(res.getInt(1));
				trans.setTransactionDesc(res.getString(2));
				trans.setDateOfTransaction(res.getDate(3));
				trans.setTransactionType(res.getString(4));
				trans.setTranAmount((res.getDouble(5)));
				trans.setAccountNo(res.getInt(6));
				mTransactions.add(trans);
				
			}
			
			if(mTransactions.isEmpty())
			{
				throw new LoginException("NO Transaction Done" );
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new LoginException("something went Wrong" +e);
		}
		
		return mTransactions;
	}
}



