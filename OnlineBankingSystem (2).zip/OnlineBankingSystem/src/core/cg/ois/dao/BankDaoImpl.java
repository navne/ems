package core.cg.ois.dao;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Customer;
import core.cg.ois.beans.ServiceTracker;
import core.cg.ois.beans.Transaction;
import core.cg.ois.beans.UserTable;
import core.cg.ois.exception.LoginException;
import core.cg.ois.util.dbUtil;



public class BankDaoImpl implements BankDao 
{
	private DataSource dataSource;
	//private int accountId=createAccountNo();

	@Override
	public void insertAccountHolder(Customer customer) throws LoginException 
	{		

		Connection connection = null;
		ResultSet res = null;
		PreparedStatement pstmt = null;
		try 
		{
			//	dataSource=DBUtil.getDataSource();
			connection=dbUtil.getConnection();
			//accountId=createAccountNo();

			pstmt=connection.prepareStatement("insert into Customer  values(?,?,?,?,?)");

			//pstmt.setLong(1, accountId);
			pstmt.setInt(1, customer.getAccountId());
			pstmt.setString(2, customer.getCustomerName());
			pstmt.setString(3, customer.getEmail());
			pstmt.setString(4, customer.getAddress());
			pstmt.setString(5,customer.getPanCard());

			pstmt.execute();

			connection.close();
		} 
		catch (SQLException  e) 
		{

			e.printStackTrace();
			throw new LoginException();
		}

	}

	@Override
	public void insertAccount(AccountMaster account) throws LoginException 
	{
		Connection connection = null;
		ResultSet res = null;
		PreparedStatement pstmt = null;
		try 
		{
			//dataSource=DBUtil.getDataSource();
			connection=dbUtil.getConnection();			
			pstmt=connection.prepareStatement("insert into AccountMaster values (?,?,?,SYSDATE)");

			//pstmt.setLong(1, accountId);
			pstmt.setInt(1, account.getAccountId());
			pstmt.setString(2, account.getAccountType());
			pstmt.setDouble(3, account.getAccountBalance());

			pstmt.execute();
			connection.close();

		} 
		catch (SQLException e) 
		{

			e.printStackTrace();
			throw new LoginException();
		}


	}

	@Override
	public void updateTracker(int accountId,int serviceId, String status) throws LoginException 
	{

		Connection connection = null;
		ResultSet res = null;
		PreparedStatement pstmt = null;
		try 
		{
			//dataSource=DBUtil.getDataSource();
			connection=dbUtil.getConnection();		
			/*dataSource=DBUtil.getDataSource();
			connection=dataSource.getConnection();*/

			pstmt=connection.prepareStatement("Update serviceTracker SET service_status=? WHERE Account_Id=? and service_id=?");
			pstmt.setInt(3, serviceId);
			pstmt.setInt(2,accountId);
			pstmt.setString(1,status);

			pstmt.execute();
			connection.close();

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw new LoginException();
		}
	}

	@Override
	public int createAccountNo() throws LoginException
	{
		Connection connection = null;
		ResultSet res = null;
		PreparedStatement pstmt = null;
		int accountId=0;
		try 
		{
			//dataSource=DBUtil.getDataSource();
			connection=dbUtil.getConnection();		
			/*dataSource=DBUtil.getDataSource();
			connection=dataSource.getConnection();
			 */
			pstmt=connection.prepareStatement("SELECT account_seq.NEXTVAL from dual");
			res=pstmt.executeQuery();
			if(res.next())
				accountId=res.getInt(1);


			connection.close();

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw new LoginException("unable to generate accountId");
		}


		return accountId;
	}

	@Override
	public List<ServiceTracker> showall() throws LoginException {
		Connection con = dbUtil.getConnection();
		PreparedStatement pstm = null;
		ServiceTracker service = null;
		String query = "Select * from servicetracker";
		List<ServiceTracker>  serviceList =  new ArrayList<ServiceTracker>();

		try {
			pstm= con.prepareStatement(query);
			ResultSet res = pstm.executeQuery();
			
			while(res.next())
			{
				service = new ServiceTracker();
				service.setServiceId(res.getInt(1));
				service.setServiceDescripton(res.getString(2));
				service.setAccountId(res.getInt(3));
				service.setServiceRaisedDate(res.getDate(4));
				service.setServiceStatus(res.getString(5));
				serviceList.add(service);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new LoginException("Error in retrieving" + e);
		}
		
		finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return serviceList;
		
		


	}
	
	public ServiceTracker searchserviceid(int serviceId) throws LoginException
	{
		
		Connection con = dbUtil.getConnection();
		PreparedStatement pstm = null;
		ServiceTracker service = null;
		String query = "Select * from servicetracker where service_id = ?";
		List<ServiceTracker>  serviceList =  new ArrayList<ServiceTracker>();

		try {
			pstm= con.prepareStatement(query);
			pstm.setInt(1, serviceId);
			ResultSet res = pstm.executeQuery();
			
			while(res.next())
			{
				service = new ServiceTracker();
				service.setServiceId(res.getInt(1));
				service.setServiceDescripton(res.getString(2));
				service.setAccountId(res.getInt(3));
				service.setServiceRaisedDate(res.getDate(4));
				service.setServiceStatus(res.getString(5));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new LoginException("Error in retrieving" + e);
		}
		
		finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return service;
	}

	@Override
	public List<Transaction> getAllTransactions() throws LoginException {
		List<Transaction> mTransactions = new ArrayList<Transaction>();
		Connection con = dbUtil.getConnection();
		Transaction trans = null;
		
		
		PreparedStatement pstm = null;
		try 
		{
			String queryFive =  "select * from transaction";
			pstm = con.prepareStatement(queryFive);
			ResultSet res = pstm.executeQuery();
			while(res.next())
			{
				trans = new Transaction();
				trans.setTransactionId(res.getInt(1));
				trans.setTransactionDesc(res.getString(2));
				trans.setDateOfTransaction(res.getDate(3));
				trans.setTransactionType(res.getString(4));
				trans.setTranAmount((res.getDouble(5)));
				trans.setAccountNo(res.getInt(6));
				mTransactions.add(trans);
				
			}
			
			if(mTransactions.isEmpty())
			{
				throw new LoginException("NO Transaction Done" );
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new LoginException("something went Wrong" +e);
		}
		finally
		{
			if(con != null && pstm != null )
			{
				try
				{
					con.close();
					pstm.close();
					
				}
				catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		
		return mTransactions;
	}

	//	public UserTable createUserTable(int accId)
	//	{
	//		Connection con = dbUtil.getConnection();
	//		PreparedStatement pstm = null;
	//		UserTable user = new UserTable();
	//		int id  = (int) Math.random();
	//		
	//		String query = "INSERT INTO USER_TABLE VALUES(?,user_seq.nextval,?,?,0,0)";
	//		
	//		pstm = con.prepareStatement(query);
	//		pstm.setInt(1, accId);
	//		pstm.setInt(2, id);
	//		
	//	}




}
